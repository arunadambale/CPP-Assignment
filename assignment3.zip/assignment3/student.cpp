#include <iostream>
#include <fstream>
using namespace std;

class Student {
private:
    int roll;
    string name;
    float marks;

public:
    // Parameterized constructor
    Student(int r = 0, string n = "", float m = 0) {
        roll = r;
        name = n;
        marks = m;
    }

    // Function to write student to file
    void writeToFile(ofstream &out) {
        out << roll << " " << name << " " << marks << endl;
    }

    // Destructor
    ~Student() {
        cout << "Destroying student ..." << endl;
    }
};

int main() {

    // Array of 3 student objects
    Student s[3] = {
        Student(1, "aruna", 85),
        Student(2, "salina", 90),
        Student(3, "Neha", 88)
    };

    // Writing to file
    ofstream fout("students.txt");
    for(int i = 0; i < 3; i++)
        s[i].writeToFile(fout);

    fout.close();

    // Reading file
    ifstream fin("students.txt");
    int r;
    string n;
    float m;

    cout << "File Contents:\n";

    while(fin >> r >> n >> m) {
        cout << r << " " << n << " " << m << endl;
    }

    fin.close();

    return 0;
}