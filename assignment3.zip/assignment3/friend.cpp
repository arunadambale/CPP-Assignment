#include <iostream>
using namespace std;

class Inspector; // Forward declaration

class Number {
private:
    int value;

public:
    Number(int v = 0) {
        value = v;
    }

    // Pre-increment
    Number& operator++() {
        ++value;
        return *this;
    }

    // Post-increment
    Number operator++(int) {
        Number temp = *this;
        value++;
        return temp;
    }

    // Assignment operator
    Number& operator=(const Number &n) {
        value = n.value;
        return *this;
    }

    // Friend function for comparison
    friend bool operator>(Number a, Number b);

    // Friend class
    friend class Inspector;
};

// Friend function definition
bool operator>(Number a, Number b) {
    return a.value > b.value;
}

// Friend class
class Inspector {
public:
    void show(Number n) {
        cout << "Private value: " << n.value << endl;
    }
};

int main() {
    Number n1(5), n2(10);

    cout << "Initial values:\n";
    Inspector I;
    I.show(n1);
    I.show(n2);

    // Pre-increment
    cout << "\nPre-increment (++n1):\n";
    ++n1;
    I.show(n1);

    // Post-increment
    cout << "\nPost-increment (n1++):\n";
    n1++;
    I.show(n1);

    // Assignment
    cout << "\nAfter assignment n1 = n2:\n";
    n1 = n2;
    I.show(n1);

    // Comparison
    if (n1 > n2)
        cout << "\nn1 is greater than n2\n";
    else
        cout << "\nn1 is not greater than n2\n";

    return 0;
}