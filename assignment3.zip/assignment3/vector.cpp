#include <iostream>
using namespace std;

class Vector {
private:
    int *arr;
    int size;

public:
    // Constructor
    Vector(int s) {
        size = s;
        arr = new int[size];
    }

    // Destructor
    ~Vector() {
        delete[] arr;
    }

    // Overload [] operator
    int& operator[](int index) {
        return arr[index];
    }

    // Overload () operator to compute sum
    int operator()() {
        int sum = 0;
        for(int i = 0; i < size; i++)
            sum += arr[i];
        return sum;
    }
};

int main() {
    Vector v(5);   // object creation

    // Initialize elements
    for(int i = 0; i < 5; i++)
        v[i] = i * 10;

    // Task demonstration
    v[2] = 50;

    cout << "Elements:\n";
    for(int i = 0; i < 5; i++)
        cout << v[i] << " ";

    cout << "\nSum of elements = " << v() << endl;

    return 0;
}