#include <iostream>
using namespace std;

class Employee {
private:
    int id;
    string name;
    mutable int accessCount;   // can change even in const function

public:
    // Parameterized constructor
    Employee(int i, string n) {
        id = i;
        name = n;
        accessCount = 0;
    }

    // User-defined copy constructor
    Employee(const Employee &e) {
        id = e.id;
        name = e.name;           // string already manages deep copy
        accessCount = e.accessCount;
        cout << "User-defined copy constructor called\n";
    }

    // Const display function
    void display() const {
        accessCount++;   // allowed because mutable
        cout << "ID: " << id << " Name: " << name 
             << " AccessCount: " << accessCount << endl;
    }
};

int main() {

    // Create object
    Employee e1(101, "Rahul");

    cout << "Calling display() multiple times:\n";
    e1.display();
    e1.display();
    e1.display();

    // Copy object
    cout << "\nCreating e2 = e1\n";
    Employee e2 = e1;

    cout << "\ne2 details:\n";
    e2.display();

    return 0;
}