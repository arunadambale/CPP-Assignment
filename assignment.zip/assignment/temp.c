#include <stdio.h>

float celsiusToFahrenheit(float c);
float fahrenheitToCelcius(float f);


int main(){ 

    float c = 25; 
    float f = 200;

    float ConvertedF = celsiusToFahrenheit(c);
    float ConvertedC = fahrenheitToCelcius(f);

    printf("Celcius to Fahrenheit: %.2fC = %.2fF\n",c,ConvertedF);
    printf("Fahrenheit to Celcius: %.2fF = %.2fC\n",f, ConvertedC);

     return 0;
     
}
   float celsiusToFahrenheit(float c){
     return((c*9/5)+32);
    }

   float fahrenheitToCelcius(float f){
    return((f-32)*5/9);

    
   
   }
    
   
   
