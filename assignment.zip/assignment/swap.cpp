#include <iostream>
using namespace std;

int main() {
    
    int x = 10, y = 20, z = 30;

    // Create pointers
    int *px = &x;
    int *py = &y;
    int *pz = &z;

    // Print before swap
    cout << "Before swap:\n";
    cout << "x = " << *px << ", y = " << *py << ", z = " << *pz << endl;

    cout << "Addresses:\n";
    cout << "px = " << px << endl;
    cout << "py = " << py << endl;
    cout << "pz = " << pz << endl;

    // Swap values of x and z using only pointers
    int temp = *px;
    *px = *pz;
    *pz = temp;

    // Print after swap
    cout << "\nAfter swap:\n";
    cout << "x = " << *px << ", y = " << *py << ", z = " << *pz << endl;

    cout << "Addresses (unchanged):\n";
    cout << "px = " << px << endl;
    cout << "py = " << py << endl;
    cout << "pz = " << pz << endl;

    return 0;
}