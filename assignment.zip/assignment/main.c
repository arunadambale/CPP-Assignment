#include <stdio.h>
int main() {
    printf("hello aruna how are u");
    return 0;
}