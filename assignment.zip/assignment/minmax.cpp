#include <iostream>
using namespace std;

// Function prototype
void findMinMax(int a, int b, int c, int &minVal, int &maxVal);

// Function definition
void findMinMax(int a, int b, int c, int &minVal, int &maxVal) {
    // Assume first number is both min and max
    minVal = a;
    maxVal = a;

    if (b < minVal)
        minVal = b;
    if (b > maxVal)
        maxVal = b;

    if (c < minVal)
        minVal = c;
    if (c > maxVal)
        maxVal = c;
}

int main() {
    int x, y, z;
    cout << "Enter three integers: ";
    cin >> x >> y >> z;

    int lo, hi;   // Variables to store results

    findMinMax(x, y, z, lo, hi);

    cout << "Minimum value: " << lo << endl;
    cout << "Maximum value: " << hi << endl;

    return 0;
}