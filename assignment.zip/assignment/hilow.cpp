#include <iostream>
#include <iomanip>
using namespace std;

// Returns absolute value using ternary operator
int absolute(int n) {
    return (n < 0) ? -n : n;
}

// Clamps value between lo and hi using nested ternary operators
int clamp(int val, int lo, int hi) {
    return (val < lo) ? lo : (val > hi) ? hi : val;
}

int main() {
    cout << left << setw(8) << "val"
         << setw(8) << "lo"
         << setw(8) << "hi"
         << setw(15) << "absolute(val)"
         << setw(20) << "clamp(val,lo,hi)"
         << endl;

    cout << "-------------------------------------------------------\n";

    // Test cases
    int vals[] = {-15, 0, 25, -3};
    int los[]  = {-10, -10, -10, 0};
    int his[]  = {10, 10, 10, 5};

    for (int i = 0; i < 4; i++) {
        cout << left << setw(8) << vals[i]
             << setw(8) << los[i]
             << setw(8) << his[i]
             << setw(15) << absolute(vals[i])
             << setw(20) << clamp(vals[i], los[i], his[i])
             << endl;
    }

    return 0;
}