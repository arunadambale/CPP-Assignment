#include <stdio.h>


int main(){
	printf("hello world______")
	return 0;
}