
#include <stdio.h>

using namespace std;


int main() {
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */   
    long a, b, sum;
    cin>>a;
    cin>>b;
    
    
   sum = a+b;
    if(sum%2==0){
       cout <<sum << "even" <<endl;
        
   }
   else{
       cout <<sum << "odd" <<endl;
    
   }
    
    return 0;
}
