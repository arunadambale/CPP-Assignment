#include <stdio.h>

int main() {
    float s1, s2, s3, s4, s5, t, percent;
    char grade;

    
    printf("Enter marks of Five Subjects:\n");
    scanf("%f %f %f %f %f", &s1, &s2, &s3, &s4, &s5);

    
    t = s1 + s2 + s3 + s4 + s5;
    percent = (t/ 500) * 100;

    
    grade = (percent >= 75) ? 'A' :
            (percent >= 60) ? 'B' :
            (percent>= 45) ? 'C' : 'F';

    // Print results
    printf("\nRESULT\n");
         printf("-----------\n");

    printf("Subject 1: %.2f\n", s1);
    printf("Subject 2: %.2f\n", s2);
    printf("Subject 3: %.2f\n", s3);
    printf("Subject 4: %.2f\n", s4);
    printf("Subject 5: %.2f\n", s5);
     printf("******************************\n");
    printf("Total Marks: %.2f\n", t);
     printf("------------------------------\n");
    printf("Percentage: %.2f%%\n", percent);
     printf("===============================\n");
    printf("Grade: %c\n", grade);
         printf("================================\n");


    return 0;
}
