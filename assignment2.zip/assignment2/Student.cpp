#include <iostream>
using namespace std;

class Student {
private:
    int rollNo;
    string name;
    float marks;

public:
    // 1. Default Constructor
    Student() {
        rollNo = 0;
        name = "unknown";
        marks = 0;
    }

    // 2. Parameterized Constructor
    Student(int r, string n, float m) {
        rollNo = r;
        name = n;
        marks = m;
    }

    // 3. Constructor using this-> pointer
    Student(int rollNo, string name, float marks) {
        this->rollNo = rollNo;
        this->name = name;
        this->marks = marks;
    }

    // Function to print student details
    void printDetails() {
        cout << "Roll No: " << rollNo << endl;
        cout << "Name: " << name << endl;
        cout << "Marks: " << marks << endl;
        cout << "=======================" << endl;
    }
};

int main() {

    // Object using default constructor
    Student s1;

    // Objects using parameterized constructors
    Student s2(1, "aruna", 85.5);
    Student s3(2, "ajinkya", 92.0);

    cout << "Student 1 Details:" << endl;
    s1.printDetails();

    cout << "Student 2 Details:" << endl;
    s2.printDetails();

    cout << "Student 3 Details:" << endl;
    s3.printDetails();

    return 0;
}