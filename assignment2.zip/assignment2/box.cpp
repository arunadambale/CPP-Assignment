#include <iostream>
using namespace std;

class Box {
private:
    int length;
    int width;
    int height;

public:
    // Parameterized Constructor
    Box(int length, int width, int height) {
        this->length = length;
        this->width = width;
        this->height = height;
    }

    // Function using this-> pointer
    void setDimensions(int length, int width, int height) {
        this->length = length;
        this->width = width;
        this->height = height;
    }

    // Function to calculate volume
    int volume() {
        return length * width * height;
    }
};

int main() {

    // Initialization using constructor
    Box box1(5, 4, 3);
    cout << "Volume using constructor: " << box1.volume() << endl;

    // Assignment using setDimensions()
    Box box2(5,4,3);
    box2.setDimensions(5,4,3);

    cout << "Volume after setDimensions(): " << box2.volume() << endl;

    return 0;
}
//Initialization happens when the object is created, while assignment happens after the object already exists.
//Initialization is preferred because it avoids garbage values, ensures objects start in a valid state, and is more efficient.