#include <iostream>
#include <cstdlib>   // required for malloc and free
using namespace std;

int main() {
    // Allocate memory for 5 integers using malloc
    int *arr = (int*) malloc(5 * sizeof(int));

    // Check if memory allocation was successful
    if(arr == NULL) {
        cout << "Memory allocation failed";
        return 1;
    }

    // Take user input
    cout << "Enter 5 integers:\n";
    for(int i = 0; i < 5; i++) {
        cin >> arr[i];
    }

    // Print the values
    cout << "The entered values are:\n";
   for(int i = 0; i < 5; i++) {

        cout << arr[i] << " ";
    
   }
    cout <<endl;

    // Deallocate memory
    free(arr);

    return 0;
}