#include <iostream>
using namespace std;

int main() {
    int num = 10;      // original variable

    int *ptr = &num;   // pointer pointing to num
    int &ref = num;    // reference to num

    cout << "Initial value of num: " << num << endl;

    // Modify using pointer
    *ptr = 20;
    cout << "After modifying using pointer: " << num << endl;

    // Modify using reference
    ref = 30;
    cout << "After modifying using reference: " << num << endl;

    return 0;
}
/*Pointer
A pointer can be changed to point to another variable.	
A pointer stores the memory address of a variable.	
Reference
A reference cannot be changed once it is initialized.
A reference is an alias (another name) for an existing variable.
*/