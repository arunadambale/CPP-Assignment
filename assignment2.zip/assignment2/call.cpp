#include <iostream>
using namespace std;

// Swap by Value
void swapByValue(int a, int b) {
    int temp = a;
    a = b;
    b = temp;
}

// Swap by Address (Pointer)
void swapByAddress(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

// Swap by Reference
void swapByReference(int &a, int &b) {
    int temp = a;
    a = b;
    b = temp;
}

int main() {
    int x = 10, y = 20;

    cout << "Original values: x = " << x << ", y = " << y << endl;

    // Call swap by value
    swapByValue(x, y);
    cout << "After swapByValue: x = " << x << ", y = " << y << endl;

    // Call swap by address
    swapByAddress(&x, &y);
    cout << "After swapByAddress: x = " << x << ", y = " << y << endl;

    // Call swap by reference
    swapByReference(x, y);
    cout << "After swapByReference: x = " << x << ", y = " << y << endl;

    return 0;
}
/*A reference variable acts as an alias (another name) 
for an existing variable, so when parameters are passed 
by reference in swapByReference(), the function operates
 directly on the original variables, allowing their values 
 to be successfully swapped.*/