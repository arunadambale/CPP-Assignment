#include <iostream>
#include <vector>
using namespace std;

class Employee {
private:
    int empID;
    string empName;
    double empSalary;

public:
    // Setters
    void setEmpID(int id) {
        empID = id;
    }

    void setEmpName(string name) {
        empName = name;
    }

    void setEmpSalary(double salary) {
        empSalary = salary;
    }

    // Getters
    int getEmpID() const {
        return empID;
    }

    string getEmpName() const {
        return empName;
    }

    double getEmpSalary() const {
        return empSalary;
    }

    // Calculate Gross Salary
    double calculateGrossSalary() const {
        double bonus = 0;

        if (empSalary <= 5000)
            bonus = empSalary * 0.10;          // 10%
        else if (empSalary <= 10000)
            bonus = empSalary * 0.15;          // 15%
        else
            bonus = empSalary * 0.20;          // 20%

        return empSalary + bonus;
    }

    // Display Employee Details
    void displayEmployeeDetails() const {
        cout << "\nEmployee Details:\n";
        cout << "ID: " << empID << endl;
        cout << "Name: " << empName << endl;
        cout << "Salary: " << empSalary << endl;
        cout << "Gross Salary: " << calculateGrossSalary() << endl;
    }
};

int main() {
    vector<Employee> employees;
    int choice;

    do {
        cout << "\n------ EMPLOYEE PAYROLL MENU ------\n";
        cout << "1. Add New Employee\n";
        cout << "2. Calculate Gross Salary\n";
        cout << "3. Display Employee Details\n";
        cout << "4. Update Employee Information\n";
        cout << "5. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == 1) {
            Employee emp;
            int id;
            string name;
            double salary;
            bool exists = false;

            cout << "Enter Employee ID: ";
            cin >> id;

            // Check unique ID
            for (const auto &e : employees) {
                if (e.getEmpID() == id) {
                    exists = true;
                    break;
                }
            }

            if (exists) {
                cout << "Employee ID already exists!\n";
            } else {
                cout << "Enter Employee Name: ";
                cin.ignore();
                getline(cin, name);

                cout << "Enter Employee Salary: ";
                cin >> salary;

                emp.setEmpID(id);
                emp.setEmpName(name);
                emp.setEmpSalary(salary);

                employees.push_back(emp);
                cout << "Employee added successfully!\n";
            }
        }

        else if (choice == 2) {
            int id;
            cout << "Enter Employee ID: ";
            cin >> id;

            bool found = false;
            for (const auto &e : employees) {
                if (e.getEmpID() == id) {
                    cout << "Gross Salary: "
                         << e.calculateGrossSalary() << endl;
                    found = true;
                    break;
                }
            }

            if (!found)
                cout << "Employee not found!\n";
        }

        else if (choice == 3) {
            int id;
            cout << "Enter Employee ID: ";
            cin >> id;

            bool found = false;
            for (const auto &e : employees) {
                if (e.getEmpID() == id) {
                    e.displayEmployeeDetails();
                    found = true;
                    break;
                }
            }

            if (!found)
                cout << "Employee not found!\n";
        }

        else if (choice == 4) {
            int id;
            cout << "Enter Employee ID to update: ";
            cin >> id;

            bool found = false;
            for (auto &e : employees) {
                if (e.getEmpID() == id) {
                    string newName;
                    double newSalary;

                    cout << "Enter New Name: ";
                    cin.ignore();
                    getline(cin, newName);

                    cout << "Enter New Salary: ";
                    cin >> newSalary;

                    e.setEmpName(newName);
                    e.setEmpSalary(newSalary);

                    cout << "Employee updated successfully!\n";
                    found = true;
                    break;
                }
            }

            if (!found)
                cout << "Employee not found!\n";
        }

    } while (choice != 5);

    cout << "Exiting program...\n";
    return 0;
}